# -*- coding: utf-8 -*-
import os

html_content = '''<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>야구(Baseball) 데이터 수집 & 정밀 분석 허브 (FastAPI)</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <style>
    body { background-color: #f1f5f9; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; }
    .header-panel { background: linear-gradient(135deg, #0b1f3a 0%, #1e3a8a 100%); color: white; padding: 2rem 0; margin-bottom: 1.5rem; box-shadow: 0 4px 12px rgba(0,0,0,0.18); }
    .match-card { border-radius: 12px; border: 1px solid #e2e8f0; transition: all 0.2s ease; cursor: pointer; }
    .match-card:hover { transform: translateY(-2px); box-shadow: 0 8px 16px -3px rgba(0,0,0,0.12); }
    .match-card.active { border: 2px solid #2563eb; background-color: #eff6ff; }
    .score-badge { font-size: 1.5rem; font-weight: 800; min-width: 90px; text-align: center; }
    .scoreboard-table th, .scoreboard-table td { text-align: center; vertical-align: middle; padding: 6px 8px; font-size: 0.88rem; }
    .scoreboard-table th { background-color: #1e293b; color: white; font-weight: 600; }
    .scoreboard-total { font-weight: bold; background-color: #f8fafc; }
    .table-stats th { font-size: 0.82rem; text-align: center; background-color: #f8fafc; }
    .table-stats td { font-size: 0.85rem; text-align: center; vertical-align: middle; }
    .quick-date-btn { font-size: 0.8rem; padding: 0.25rem 0.6rem; }
    .nav-tabs .nav-link.active { font-weight: bold; border-bottom: 3px solid #2563eb; }
    .cursor-pointer { cursor: pointer; }
  </style>
</head>
<body>

  <!-- 헤더 -->
  <div class="header-panel">
    <div class="container">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <span class="badge bg-warning text-dark mb-2 px-3 py-1 fw-bold"><i class="bi bi-baseball me-1"></i>BASEBALL PRECISION HUB</span>
          <h2 class="fw-bold mb-1"><i class="bi bi-trophy-fill text-warning me-2"></i>야구 정밀 데이터 수집 & 앱 관리 센터</h2>
          <p class="text-white-50 mb-0">
            한국 프로야구(KBO 리그) · 미국 메이저리그(MLB) <b>100% 공식 실시간 데이터 수집 & 이닝별/타자/투수 세부 지표 편집기</b>
          </p>
        </div>
        <div>
          <a href="/docs" target="_blank" class="btn btn-outline-light me-2"><i class="bi bi-code-slash me-1"></i>API 명세서</a>
        </div>
      </div>
    </div>
  </div>

  <div class="container mb-5">
    <!-- 팀 & 선수별 폴더 구조 내보내기 배너 -->
    <div class="card border-0 shadow-sm mb-4" style="background: linear-gradient(135deg, #1d4ed8 0%, #0f172a 100%); color: white;">
      <div class="card-body p-4 d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div>
          <span class="badge bg-warning text-dark mb-1 fw-bold">⚡ 원클릭 자동 수집</span>
          <h5 class="fw-bold mb-1">방금 끝난 야구 경기 1회부터 9회(연장)까지 즉시 공식 실시간 수집</h5>
          <p class="mb-0 text-white-50 small">실행 버튼만 클릭하면 공식 사이트(KBO / MLB / NPB)에서 1~9회 스코어보드, 출전 전 선수 지표를 1초 만에 자동 수집합니다.</p>
        </div>
        <div class="d-flex gap-2">
          <button id="btnSyncLatest" class="btn btn-warning text-dark fw-bold px-4 py-2 shadow" onclick="triggerSyncLatest()">
            <i class="bi bi-lightning-charge-fill me-1"></i> 방금 끝난 경기 즉시 자동 수집
          </button>
          <button class="btn btn-outline-light fw-semibold px-3 py-2" onclick="openFolderExportModal()">
            <i class="bi bi-folder-symlink-fill me-1"></i> 구단/선수별 폴더 생성
          </button>
        </div>
        <div class="w-100 mt-2 pt-2 border-top border-secondary d-flex justify-content-between align-items-center flex-wrap gap-2 small">
          <div id="schedulerStatusDiv">
            <span class="badge bg-success me-1"><i class="bi bi-clock-history me-1"></i>일일 자동 수집 가동 중</span>
            <span class="text-white-50">매일 자정(00:00) KBO · NPB · MLB 경기 및 세이버메트릭스 자동 갱신</span>
            <span id="schedulerNextRunBadge" class="badge bg-dark ms-2 text-warning">다음 예정: 조회 중...</span>
          </div>
          <div>
            <button id="btnRunSchedulerNow" class="btn btn-sm btn-outline-warning fw-bold" onclick="triggerSchedulerNow()">
              <i class="bi bi-arrow-repeat me-1"></i>지금 즉시 전체 일일 자동 수집 실행
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- 기간별 크롤링 및 필터링 제어 패널 -->
    <div class="card shadow-sm mb-4 border-0">
      <div class="card-body">
        <div class="row g-3 align-items-end">
          <!-- 1. 야구 리그 선택 -->
          <div class="col-lg-4 col-md-6">
            <label class="form-label fw-semibold mb-1"><i class="bi bi-baseball me-1 text-primary"></i>대상 야구 리그 선택</label>
            <select id="selectLeague" class="form-select" onchange="loadMatches()">
              <option value="ALL">⚾ 전체 야구 리그 (KBO + MLB + NPB 공식 전체)</option>
              <option value="KBO" selected>🇰🇷 한국 프로야구 (KBO 리그) [100% 공식 실시간]</option>
              <option value="MLB">🇺🇸 미국 메이저리그 (MLB) [100% 공식 실시간]</option>
              <option value="NPB">🇯🇵 일본 프로야구 (NPB) [100% 공식 실시간]</option>
            </select>
          </div>

          <!-- 2. 수집 기간 (몇일부터 ~ 몇일까지) -->
          <div class="col-lg-5 col-md-6">
            <div class="d-flex justify-content-between align-items-center mb-1">
              <label class="form-label fw-semibold mb-0"><i class="bi bi-calendar-range me-1 text-primary"></i>수집 기간 범위 (시작일 ~ 종료일)</label>
              <div class="btn-group">
                <button type="button" class="btn btn-outline-secondary quick-date-btn" onclick="setQuickDate('today')">오늘</button>
                <button type="button" class="btn btn-outline-secondary quick-date-btn" onclick="setQuickDate('3days')">최근3일</button>
                <button type="button" class="btn btn-outline-secondary quick-date-btn" onclick="setQuickDate('week')">최근1주</button>
                <button type="button" class="btn btn-outline-secondary quick-date-btn" onclick="setQuickDate('month')">최근1달</button>
              </div>
            </div>
            <div class="input-group">
              <span class="input-group-text bg-light">시작</span>
              <input type="date" id="startDate" class="form-control" value="2026-09-01">
              <span class="input-group-text bg-light">~ 종료</span>
              <input type="date" id="endDate" class="form-control" value="2026-09-07">
            </div>
          </div>

          <!-- 3. 수집 버튼 & 조회 버튼 -->
          <div class="col-lg-3 col-md-12 d-flex gap-2">
            <button id="btnSync" class="btn btn-primary flex-fill py-2 fw-semibold" onclick="triggerSync()">
              <i class="bi bi-cloud-arrow-down-fill me-1"></i> 기간 야구 데이터 일괄 수집
            </button>
            <button class="btn btn-outline-secondary py-2" title="목록 새로고침" onclick="loadMatches()">
              <i class="bi bi-arrow-clockwise"></i>
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- 2분할 레이아웃: 좌측 경기목록, 우측 상세 및 수정 -->
    <div class="row">
      <!-- 좌측: 경기 목록 -->
      <div class="col-lg-5">
        <div class="card border-0 shadow-sm mb-4">
          <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
            <h5 class="mb-0 fw-bold"><i class="bi bi-calendar-check me-2 text-primary"></i>야구 경기 일정 및 결과</h5>
            <span id="matchCountBadge" class="badge bg-primary">0 경기</span>
          </div>
          <div class="p-2 border-bottom bg-light d-flex flex-column gap-2">
            <input type="text" id="teamSearchInput" class="form-control form-control-sm" placeholder="🔍 구단명 검색 (예: 샌디에이고, 양키스, 다저스...)" oninput="filterMatches()">
            <div class="btn-group btn-group-sm w-100" role="group">
              <button type="button" class="btn btn-outline-primary active" id="filterStatusAll" onclick="setStatusFilter('ALL')">전체 경기</button>
              <button type="button" class="btn btn-outline-success" id="filterStatusFinished" onclick="setStatusFilter('FINISHED')">⚾ 경기종료 (전광판/기록)</button>
              <button type="button" class="btn btn-outline-secondary" id="filterStatusScheduled" onclick="setStatusFilter('SCHEDULED')">예정 경기</button>
            </div>
          </div>
          <div class="card-body p-3" id="matchesList" style="max-height: 800px; overflow-y: auto;">
            <div class="text-center py-5 text-muted">
              <div class="spinner-border spinner-border-sm mb-2" role="status"></div>
              <div>야구 경기 데이터를 불러오는 중입니다...</div>
            </div>
          </div>
        </div>
      </div>

      <!-- 우측: 선택된 경기 상세, 이닝별 스코어보드, 타자/투수 세부 지표, 앱 연동 JSON -->
      <div class="col-lg-7">
        <div id="matchDetailView" style="display: none;">
          <!-- 경기 헤더 카드 -->
          <div class="card border-0 shadow-sm mb-4">
            <div class="card-body">
              <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="badge bg-primary" id="detailLeagueBadge"></span>
                <span class="text-muted small" id="detailTime"></span>
                <span id="detailStatusBadge" class="badge"></span>
              </div>
              <div class="d-flex justify-content-around align-items-center text-center my-3">
                <div style="flex: 1;">
                  <h4 class="fw-bold mb-1 text-truncate text-primary" id="detailHomeTeam"></h4>
                  <span class="badge bg-light text-muted border">말공 (HOME)</span>
                </div>
                <div class="px-3">
                  <div class="badge bg-dark score-badge px-4 py-2 text-white shadow-sm" id="detailScore">0 : 0</div>
                </div>
                <div style="flex: 1;">
                  <h4 class="fw-bold mb-1 text-truncate text-danger" id="detailAwayTeam"></h4>
                  <span class="badge bg-light text-muted border">초공 (AWAY)</span>
                </div>
              </div>

              <!-- 경기 스코어 직접 수정 토글 버튼 -->
              <div class="border-top pt-3 d-flex justify-content-between align-items-center">
                <small class="text-muted" id="detailStadium"></small>
                <button class="btn btn-sm btn-outline-primary" onclick="toggleEditMatchScore()">
                  <i class="bi bi-pencil-square me-1"></i>경기 결과 스코어 직접 수정
                </button>
              </div>

              <!-- 스코어 수정 폼 -->
              <div id="scoreEditForm" class="mt-3 p-3 bg-light rounded" style="display: none;">
                <h6 class="fw-bold mb-2">경기 최종 스코어 및 상태 직접 변경</h6>
                <div class="row g-2 align-items-center">
                  <div class="col">
                    <label class="small text-muted">홈팀 점수(R)</label>
                    <input type="number" id="editHomeScore" class="form-control form-control-sm">
                  </div>
                  <div class="col">
                    <label class="small text-muted">원정팀 점수(R)</label>
                    <input type="number" id="editAwayScore" class="form-control form-control-sm">
                  </div>
                  <div class="col">
                    <label class="small text-muted">경기 상태</label>
                    <select id="editStatus" class="form-select form-select-sm">
                      <option value="SCHEDULED">경기전 (SCHEDULED)</option>
                      <option value="LIVE">진행중 (LIVE)</option>
                      <option value="FINISHED">경기종료 (FINISHED)</option>
                    </select>
                  </div>
                  <div class="col-auto align-self-end">
                    <button class="btn btn-sm btn-success" onclick="saveMatchScore()">저장 및 앱 반영</button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- 1~9회 전광판 정밀 스코어보드 -->
          <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
              <h6 class="mb-0 fw-bold"><i class="bi bi-grid-3x3 me-2 text-primary"></i>1~9회 이닝별 전광판 스코어보드 (R · H · E · B)</h6>
            </div>
            <div class="card-body p-0">
              <div class="table-responsive">
                <table class="table table-bordered scoreboard-table mb-0" id="scoreboardTable">
                  <!-- 동적 렌더링 -->
                </table>
              </div>
            </div>
          </div>

          <!-- 타자 기록 & 투수 기록 탭 -->
          <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white pt-3 pb-0">
              <div class="d-flex justify-content-between align-items-center mb-2">
                <h6 class="mb-0 fw-bold"><i class="bi bi-person-lines-fill me-2 text-primary"></i>출전 선수 정밀 세부 기록 (타자 · 투수)</h6>
                <div class="btn-group" role="group">
                  <button type="button" class="btn btn-sm btn-primary active" id="btnFilterAll" onclick="filterPlayerTeam('ALL')">양팀 전체</button>
                  <button type="button" class="btn btn-sm btn-outline-primary" id="btnFilterHome" onclick="filterPlayerTeam('HOME')">홈팀 선수</button>
                  <button type="button" class="btn btn-sm btn-outline-primary" id="btnFilterAway" onclick="filterPlayerTeam('AWAY')">원정팀 선수</button>
                </div>
              </div>
              <ul class="nav nav-tabs border-bottom-0" id="baseballTab" role="tablist">
                <li class="nav-item">
                  <button class="nav-link active" id="hitters-tab" data-bs-toggle="tab" data-bs-target="#hitters-content" type="button"><i class="bi bi-lightning-fill text-warning me-1"></i>타자 기록 (Batters)</button>
                </li>
                <li class="nav-item">
                  <button class="nav-link" id="pitchers-tab" data-bs-toggle="tab" data-bs-target="#pitchers-content" type="button"><i class="bi bi-shield-shaded text-primary me-1"></i>투수 기록 (Pitchers)</button>
                </li>
              </ul>
              <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 p-2 bg-light border-top border-bottom">
                <!-- 지표 모드 토글 -->
                <div class="d-flex align-items-center gap-2">
                  <span class="small fw-bold text-dark"><i class="bi bi-sliders me-1 text-primary"></i>지표 모드:</span>
                  <div class="btn-group btn-group-sm" role="group">
                    <button type="button" class="btn btn-primary active fw-semibold" id="btnModeClassic" onclick="setStatMode('CLASSIC')">⚾ 기본 클래식 기록</button>
                    <button type="button" class="btn btn-outline-dark fw-semibold" id="btnModeSaber" onclick="setStatMode('SABER')">🔬 세이버메트릭스 (wOBA·FIP·BABIP·ISO)</button>
                  </div>
                </div>

                <!-- 분석 구간 3, 5, 7, 10단위 선택 -->
                <div class="d-flex align-items-center gap-2">
                  <span class="small fw-bold text-dark"><i class="bi bi-clock-history me-1 text-primary"></i>분석 구간:</span>
                  <div class="btn-group btn-group-sm" role="group">
                    <button type="button" class="btn btn-outline-primary" id="btnWin3" onclick="setStatWindow(3)">3단위</button>
                    <button type="button" class="btn btn-primary active" id="btnWin5" onclick="setStatWindow(5)">5단위</button>
                    <button type="button" class="btn btn-outline-primary" id="btnWin7" onclick="setStatWindow(7)">7단위</button>
                    <button type="button" class="btn btn-outline-primary" id="btnWin10" onclick="setStatWindow(10)">10단위</button>
                  </div>
                  <!-- 기준 토글 (경기수 / 날짜) -->
                  <div class="btn-group btn-group-sm ms-1" role="group">
                    <button type="button" class="btn btn-secondary active" id="btnUnitGames" onclick="setStatUnit('games')">경기수 기준</button>
                    <button type="button" class="btn btn-outline-secondary" id="btnUnitDays" onclick="setStatUnit('days')">날짜(일) 기준</button>
                  </div>
                </div>
              </div>
            </div>
            <div class="card-body p-0">
              <div class="tab-content" id="baseballTabContent">
                <!-- 1. 타자 테이블 -->
                <div class="tab-pane fade show active" id="hitters-content" role="tabpanel">
                  <div class="table-responsive" style="max-height: 460px; overflow-y: auto;">
                    <table class="table table-hover table-stats align-middle mb-0">
                      <thead class="sticky-top" id="hittersThead"></thead>
                      <tbody id="hittersTableBody"></tbody>
                    </table>
                  </div>
                </div>

                <!-- 2. 투수 테이블 -->
                <div class="tab-pane fade" id="pitchers-content" role="tabpanel">
                  <div class="table-responsive" style="max-height: 460px; overflow-y: auto;">
                    <table class="table table-hover table-stats align-middle mb-0">
                      <thead class="sticky-top" id="pitchersThead"></thead>
                      <tbody id="pitchersTableBody"></tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- 주요 승부처 타임라인 (홈런/적시타 등) -->
          <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
              <h6 class="mb-0 fw-bold"><i class="bi bi-clock-history me-2 text-primary"></i>주요 경기 상황 및 타점/홈런 타임라인</h6>
              <button class="btn btn-sm btn-outline-primary fw-semibold" onclick="openDomainEmbedModal()">
                <i class="bi bi-code-slash me-1"></i>내 도메인에 타임라인 올리기 (퍼가기)
              </button>
            </div>
            <div class="card-body p-3" id="eventsTimeline">
            </div>
          </div>

          <!-- 앱/클라이언트 연동 JSON API 미리보기 -->
          <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
              <h6 class="mb-0 fw-bold"><i class="bi bi-braces me-2 text-primary"></i>앱(클라이언트) 전송용 JSON API 데이터</h6>
              <button class="btn btn-sm btn-outline-secondary" onclick="copyApiJson()"><i class="bi bi-clipboard me-1"></i>JSON 복사</button>
            </div>
            <div class="card-body p-0">
              <pre id="apiJsonPreview" class="bg-dark text-light p-3 m-0" style="max-height: 280px; overflow-y: auto; font-size: 0.82rem; border-radius: 0 0 12px 12px;"></pre>
            </div>
          </div>
        </div>

        <div id="noMatchSelected" class="text-center py-5 text-muted card border-0 shadow-sm">
          <div class="card-body py-5">
            <i class="bi bi-baseball text-secondary" style="font-size: 3.5rem;"></i>
            <h5 class="mt-3 fw-bold">조회할 야구 경기를 좌측 목록에서 선택하세요</h5>
            <p class="text-muted small">이닝별 스코어보드, 9번 타순까지의 타자 기록, 투수 세부 투구 수치를 확인하고 수정할 수 있습니다.</p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- 선수 기록 수정 모달 (타자/투수 공용 정밀 편집기) -->
  <div class="modal fade" id="playerEditModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content">
        <div class="modal-header bg-primary text-white">
          <h5 class="modal-title fw-bold" id="playerModalTitle"><i class="bi bi-pencil-square me-2"></i>야구 선수 세부 지표 수정</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body p-4">
          <input type="hidden" id="modalStatId">
          <input type="hidden" id="modalPlayerType">

          <!-- 타자 수정 폼 필드들 -->
          <div id="hitterEditFields">
            <h6 class="fw-bold text-primary mb-3"><i class="bi bi-lightning-fill text-warning me-1"></i>타격 세부 지표</h6>
            <div class="row g-3">
              <div class="col-md-3 col-6">
                <label class="form-label small fw-semibold">타수 (AB)</label>
                <input type="number" id="editHitterAB" class="form-control">
              </div>
              <div class="col-md-3 col-6">
                <label class="form-label small fw-semibold">득점 (R)</label>
                <input type="number" id="editHitterR" class="form-control">
              </div>
              <div class="col-md-3 col-6">
                <label class="form-label small fw-semibold">안타 (H)</label>
                <input type="number" id="editHitterH" class="form-control">
              </div>
              <div class="col-md-3 col-6">
                <label class="form-label small fw-semibold">2루타 (2B)</label>
                <input type="number" id="editHitter2B" class="form-control">
              </div>
              <div class="col-md-3 col-6">
                <label class="form-label small fw-semibold">3루타 (3B)</label>
                <input type="number" id="editHitter3B" class="form-control">
              </div>
              <div class="col-md-3 col-6">
                <label class="form-label small fw-semibold">홈런 (HR)</label>
                <input type="number" id="editHitterHR" class="form-control">
              </div>
              <div class="col-md-3 col-6">
                <label class="form-label small fw-semibold">타점 (RBI)</label>
                <input type="number" id="editHitterRBI" class="form-control">
              </div>
              <div class="col-md-3 col-6">
                <label class="form-label small fw-semibold">볼넷 (BB)</label>
                <input type="number" id="editHitterBB" class="form-control">
              </div>
              <div class="col-md-3 col-6">
                <label class="form-label small fw-semibold">삼진 (SO)</label>
                <input type="number" id="editHitterSO" class="form-control">
              </div>
              <div class="col-md-3 col-6">
                <label class="form-label small fw-semibold">도루 (SB)</label>
                <input type="number" id="editHitterSB" class="form-control">
              </div>
              <div class="col-md-3 col-6">
                <label class="form-label small fw-semibold">시즌 타율 (AVG)</label>
                <input type="text" id="editHitterAVG" class="form-control" placeholder="0.312">
              </div>
              <div class="col-md-3 col-6">
                <label class="form-label small fw-semibold">시즌 OPS</label>
                <input type="text" id="editHitterOPS" class="form-control" placeholder="1.045">
              </div>
            </div>
          </div>

          <!-- 투수 수정 폼 필드들 -->
          <div id="pitcherEditFields" style="display: none;">
            <h6 class="fw-bold text-primary mb-3"><i class="bi bi-shield-shaded text-primary me-1"></i>투구 세부 지표</h6>
            <div class="row g-3">
              <div class="col-md-3 col-6">
                <label class="form-label small fw-semibold">투구이닝 (IP)</label>
                <input type="text" id="editPitcherIP" class="form-control" placeholder="6.0">
              </div>
              <div class="col-md-3 col-6">
                <label class="form-label small fw-semibold">투구수 (NP)</label>
                <input type="number" id="editPitcherNP" class="form-control">
              </div>
              <div class="col-md-3 col-6">
                <label class="form-label small fw-semibold">피안타 (H)</label>
                <input type="number" id="editPitcherH" class="form-control">
              </div>
              <div class="col-md-3 col-6">
                <label class="form-label small fw-semibold">실점 (R)</label>
                <input type="number" id="editPitcherR" class="form-control">
              </div>
              <div class="col-md-3 col-6">
                <label class="form-label small fw-semibold">자책점 (ER)</label>
                <input type="number" id="editPitcherER" class="form-control">
              </div>
              <div class="col-md-3 col-6">
                <label class="form-label small fw-semibold">볼넷/사구 (BB)</label>
                <input type="number" id="editPitcherBB" class="form-control">
              </div>
              <div class="col-md-3 col-6">
                <label class="form-label small fw-semibold">탈삼진 (SO)</label>
                <input type="number" id="editPitcherSO" class="form-control">
              </div>
              <div class="col-md-3 col-6">
                <label class="form-label small fw-semibold">피홈런 (HR)</label>
                <input type="number" id="editPitcherHR" class="form-control">
              </div>
              <div class="col-md-4 col-6">
                <label class="form-label small fw-semibold">평균자책점 (ERA)</label>
                <input type="text" id="editPitcherERA" class="form-control" placeholder="2.92">
              </div>
              <div class="col-md-4 col-6">
                <label class="form-label small fw-semibold">WHIP</label>
                <input type="text" id="editPitcherWHIP" class="form-control" placeholder="1.08">
              </div>
              <div class="col-md-4 col-12">
                <label class="form-label small fw-semibold">승패 결과 (Decision)</label>
                <input type="text" id="editPitcherDecision" class="form-control" placeholder="승리투수 (W)">
              </div>
            </div>
          </div>

          <div class="mt-4">
            <label class="form-label small fw-semibold">수정 사유 (관리자 메모)</label>
            <input type="text" id="editReason" class="form-control" placeholder="공식 기록 정정 또는 앱 전송용 보정">
          </div>
        </div>
        <div class="modal-footer bg-light">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">취소</button>
          <button type="button" class="btn btn-primary px-4" onclick="savePlayerStat()"><i class="bi bi-check-lg me-1"></i>수정 저장 및 앱 동기화</button>
        </div>
      </div>
    </div>
  </div>

  <!-- 팀/선수별 폴더 내보내기 모달 -->
  <div class="modal fade" id="folderExportModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content">
        <div class="modal-header bg-dark text-white">
          <h5 class="modal-title fw-bold"><i class="bi bi-folder-symlink-fill text-warning me-2"></i>야구단 & 선수별 폴더 구조 파일 생성</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body p-4">
          <div class="alert alert-primary d-flex align-items-center mb-3">
            <i class="bi bi-info-circle-fill me-2 fs-5"></i>
            <div>
              지정한 기간 동안의 <b>전체 팀 폴더</b>를 디스크에 자동 생성하고, 각 팀 안에 <b>hitters/ (타자 파일)</b>, <b>pitchers/ (투수 파일)</b>, <b>matches/ (경기 파일)</b>를 분류 저장합니다.
            </div>
          </div>

          <div class="row g-3 mb-3">
            <div class="col-md-6">
              <label class="form-label fw-semibold">대상 야구 리그</label>
              <select id="exportModalLeague" class="form-select">
                <option value="KBO" selected>🇰🇷 한국 프로야구 (KBO 리그) [100% 공식 실시간]</option>
                <option value="MLB">🇺🇸 미국 메이저리그 (MLB) [100% 공식 실시간]</option>
                <option value="NPB">🇯🇵 일본 프로야구 (NPB) [100% 공식 실시간]</option>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold">수집 기간 (시작 ~ 종료)</label>
              <div class="input-group">
                <input type="date" id="exportModalStart" class="form-control" value="2026-09-01">
                <span class="input-group-text">~</span>
                <input type="date" id="exportModalEnd" class="form-control" value="2026-09-07">
              </div>
            </div>
          </div>

          <!-- 폴더 구조 미리보기 다이어그램 -->
          <div class="bg-light p-3 rounded border mb-3">
            <h6 class="fw-bold mb-2 text-dark"><i class="bi bi-diagram-3-fill me-1 text-primary"></i>자동 생성되는 폴더 계층 구조:</h6>
            <pre class="m-0 text-secondary" style="font-family: monospace; font-size: 0.85rem;">
📁 exports/
   └── 📁 MLB/ (또는 KBO, NPB)
        └── 📁 LA_다저스/
             ├── 📄 team_summary.json  (팀 전체 경기 요약 및 선수 명단)
             ├── 📁 hitters/
             │    ├── 📄 오타니_쇼헤이.json (타수, 안타, 홈런, 타점, OPS)
             │    └── 📄 무키_베츠.json ...
             ├── 📁 pitchers/
             │    ├── 📄 야마모토_요시노부.json (이닝, 탈삼진, ERA, WHIP)
             │    └── 📄 에반_필립스.json ...
             └── 📁 matches/
                  └── 📄 2026-09-05_vs_샌디에이고_파드리스.json (1~9회 스코어보드)</pre>
          </div>

          <div id="exportResultArea" style="display: none;" class="p-3 bg-success-subtle rounded border border-success">
            <div class="d-flex justify-content-between align-items-center">
              <div>
                <h6 class="fw-bold text-success mb-1"><i class="bi bi-check-circle-fill me-1"></i>폴더 구조 파일 생성이 완료되었습니다!</h6>
                <p class="mb-0 text-muted small" id="exportResultText"></p>
              </div>
              <div>
                <a id="btnDownloadZip" href="#" class="btn btn-success fw-bold px-3 py-2">
                  <i class="bi bi-file-earmark-zip-fill me-1"></i>ZIP 파일 다운로드
                </a>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer bg-light">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">닫기</button>
          <button type="button" id="btnExecuteExport" class="btn btn-primary px-4 fw-bold" onclick="executeFolderExport()">
            <i class="bi bi-folder-plus me-1"></i>폴더 생성 실행하기
          </button>
        </div>
  <!-- 내 도메인에 타임라인 올리기(퍼가기) 모달 -->
  <div class="modal fade" id="domainEmbedModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content">
        <div class="modal-header bg-dark text-white">
          <h5 class="modal-title fw-bold"><i class="bi bi-globe me-2 text-warning"></i>내 도메인/웹사이트에 타점·홈런 타임라인 올리기</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body p-4">
          <div class="alert alert-info d-flex align-items-center mb-3">
            <i class="bi bi-info-circle-fill me-2 fs-4"></i>
            <div>
              수집된 실시간 타점/홈런 타임라인은 <b>iFrame 위젯</b>, <b>REST API</b>, <b>HTML 파일 업로드</b> 등 3가지 방법으로 내 도메인에 자유롭게 게시할 수 있습니다.
            </div>
          </div>

          <!-- 방법 1: iframe 위젯 -->
          <div class="card mb-3 border">
            <div class="card-header bg-light py-2 d-flex justify-content-between align-items-center">
              <strong class="text-primary"><i class="bi bi-window-fullscreen me-1"></i>[방법 1] HTML iFrame 위젯 코드 (가장 쉬운 1줄 삽입)</strong>
              <button class="btn btn-sm btn-outline-primary" onclick="copyIframeCode()"><i class="bi bi-clipboard me-1"></i>iFrame 코드 복사</button>
            </div>
            <div class="card-body p-3">
              <p class="small text-muted mb-2">내 홈페이지, 워드프레스, 블로그, 쇼핑몰의 원하는 위치에 아래 태그를 붙여넣기만 하면 실시간 타임라인 위젯이 바로 뜹니다:</p>
              <pre class="bg-dark text-light p-2 rounded small m-0" id="embedIframePreview" style="font-family: monospace; white-space: pre-wrap;"></pre>
              <div class="mt-2 text-end">
                <a id="btnPreviewWidget" href="/embed/timeline/latest" target="_blank" class="btn btn-sm btn-outline-success">
                  <i class="bi bi-box-arrow-up-right me-1"></i>위젯 새 창 미리보기
                </a>
              </div>
            </div>
          </div>

          <!-- 방법 2: REST API JSON 호출 -->
          <div class="card mb-3 border">
            <div class="card-header bg-light py-2 d-flex justify-content-between align-items-center">
              <strong class="text-success"><i class="bi bi-code-square me-1"></i>[방법 2] 내 웹/앱에서 직접 호출 (REST API JSON)</strong>
              <button class="btn btn-sm btn-outline-success" onclick="copyApiCode()"><i class="bi bi-clipboard me-1"></i>API 스니펫 복사</button>
            </div>
            <div class="card-body p-3">
              <p class="small text-muted mb-2">React, Vue, Node.js, PHP 등 내 백엔드/프론트엔드에서 실시간 JSON 데이터를 받아와 자유롭게 디자인할 수 있습니다 (CORS 허용됨):</p>
              <pre class="bg-dark text-light p-2 rounded small m-0" id="embedApiPreview" style="font-family: monospace; white-space: pre-wrap;"></pre>
            </div>
          </div>

          <!-- 방법 3: 파일 자동 업로드 가이드 -->
          <div class="card border">
            <div class="card-header bg-light py-2">
              <strong class="text-dark"><i class="bi bi-cloud-arrow-up-fill me-1"></i>[방법 3] 정적 파일 / 웹호스팅 자동 업로드 (FTP, AWS S3 등)</strong>
            </div>
            <div class="card-body p-3 small text-secondary">
              수집 완료 시 생성되는 <code>방금끝난경기_전광판_상세결과.html</code> 또는 <code>exports/MLB/</code> 폴더를 내 웹호스팅 서버(FTP, Cafe24, 가비아, AWS S3 등)로 자동 전송하도록 연동할 수 있습니다.
            </div>
          </div>
        </div>
        <div class="modal-footer bg-light">
          <button type="button" class="btn btn-secondary px-4" data-bs-dismiss="modal">닫기</button>
        </div>
      </div>
    </div>
  </div>

  <!-- 선수 최근 3G / 5G 롤링 지표 & 게임로그 모달 -->
  <div class="modal fade" id="playerTrendModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content border-0 shadow">
        <div class="modal-header bg-dark text-white">
          <h5 class="modal-title fw-bold" id="trendModalTitle"><i class="bi bi-graph-up-arrow text-warning me-2"></i>선수 롤링 평균 지표 분석</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body p-4" id="trendModalBody">
          <!-- 상단 듀얼 모드 토글 (경기수 / 일수) -->
          <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
            <div class="fw-bold fs-6 text-dark"><i class="bi bi-pie-chart-fill me-1 text-primary"></i>구간별 세이버메트릭스 & 롤링 종합 지표</div>
            <div class="btn-group btn-group-sm">
              <button type="button" class="btn btn-primary active" id="modalUnitGames" onclick="setModalTrendUnit('games')">경기수 기준 (3G · 5G · 7G · 10G)</button>
              <button type="button" class="btn btn-outline-primary" id="modalUnitDays" onclick="setModalTrendUnit('days')">날짜(일) 기준 (3D · 5D · 7D · 10D)</button>
            </div>
          </div>

          <!-- 4개 구간 카드 (3, 5, 7, 10단위) -->
          <div class="row g-2 mb-4" id="trendCardsContainer"></div>

          <!-- 최근 경기별 상세 박스스코어 테이블 -->
          <h6 class="fw-bold mb-2 text-dark"><i class="bi bi-calendar3 me-1 text-primary"></i>수집 데이터 기반 최근 경기별 상세 로그</h6>
          <div class="table-responsive border rounded" style="max-height: 280px; overflow-y: auto;">
            <table class="table table-hover table-sm text-center mb-0 align-middle" id="trendGameLogsTable">
              <thead class="table-light sticky-top" id="trendLogsThead"></thead>
              <tbody id="trendLogsTbody"></tbody>
            </table>
          </div>
        </div>
        <div class="modal-footer bg-light">
          <button type="button" class="btn btn-secondary px-4" data-bs-dismiss="modal">닫기</button>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    let currentMatches = [];
    let selectedMatch = null;
    let currentMatchRolling = {};
    let playerFilter = 'ALL';
    let editModalObj = null;
    let folderModalObj = null;
    let domainModalObj = null;
    let trendModalObj = null;
    let statMode = 'CLASSIC'; // 'CLASSIC' or 'SABER'
    let statWindow = 5;       // 3, 5, 7, 10
    let statUnit = 'games';   // 'games' or 'days'
    let currentTrendPlayerData = null;
    let currentTrendPlayerType = 'hitter';
    let trendModalUnit = 'games';

    document.addEventListener('DOMContentLoaded', () => {
      editModalObj = new bootstrap.Modal(document.getElementById('playerEditModal'));
      folderModalObj = new bootstrap.Modal(document.getElementById('folderExportModal'));
      domainModalObj = new bootstrap.Modal(document.getElementById('domainEmbedModal'));
      trendModalObj = new bootstrap.Modal(document.getElementById('playerTrendModal'));
      setQuickDate('week');
      loadMatches();
      loadSchedulerStatus();
    });

    async function loadSchedulerStatus() {
      try {
        const res = await fetch('/api/v1/scheduler/status');
        if (!res.ok) return;
        const data = await res.json();
        const nextRunBadge = document.getElementById('schedulerNextRunBadge');
        if (nextRunBadge && data.next_run_time) {
          const dt = new Date(data.next_run_time);
          nextRunBadge.textContent = `다음 자동 실행: ${dt.toLocaleString()}`;
        }
      } catch (e) {
        console.warn('스케줄러 상태 확인 실패:', e);
      }
    }

    async function triggerSchedulerNow() {
      const btn = document.getElementById('btnRunSchedulerNow');
      if (!confirm('KBO, NPB, MLB의 어제/오늘 경기 및 세이버메트릭스 폴더 갱신을 백그라운드에서 지금 즉시 실행하시겠습니까?')) return;
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>전체 자동 수집 실행 중...';
      try {
        const res = await fetch('/api/v1/scheduler/run-now', { method: 'POST' });
        const data = await res.json();
        alert(data.message || '백그라운드 일일 자동 수집이 시작되었습니다.');
        setTimeout(() => { loadMatches(); loadSchedulerStatus(); }, 3000);
      } catch (e) {
        alert('실행 요청 실패: ' + e);
      } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="bi bi-arrow-repeat me-1"></i>지금 즉시 전체 일일 자동 수집 실행';
      }
    }

    function openDomainEmbedModal() {
      const origin = window.location.origin;
      const m = selectedMatch ? (selectedMatch.match || selectedMatch) : null;
      const mId = m ? m.id : 'latest';
      const iframeUrl = `${origin}/embed/timeline/${mId}`;
      const apiUrl = `${origin}/api/v1/matches/${mId}/timeline`;

      const iframeCode = `<iframe src="${iframeUrl}" width="100%" height="460" frameborder="0" style="border: 1px solid #e2e8f0; border-radius: 12px; max-width: 800px;"></iframe>`;
      document.getElementById('embedIframePreview').textContent = iframeCode;
      document.getElementById('btnPreviewWidget').href = iframeUrl;

      const apiCode = `// 내 웹사이트(JavaScript)에서 실시간 타임라인 불러오기
fetch('${apiUrl}')
  .then(res => res.json())
  .then(data => {
    console.log('경기 정보:', data.match);
    console.log('주요 상황 및 타점/홈런 목록:', data.timeline);
    // 원하는 디자인으로 자유롭게 렌더링
  });`;
      document.getElementById('embedApiPreview').textContent = apiCode;

      domainModalObj.show();
    }

    function copyIframeCode() {
      const txt = document.getElementById('embedIframePreview').textContent;
      navigator.clipboard.writeText(txt).then(() => {
        alert('iFrame 위젯 코드가 클립보드에 복사되었습니다. 내 웹페이지 원하는 위치에 붙여넣으세요.');
      });
    }

    function copyApiCode() {
      const txt = document.getElementById('embedApiPreview').textContent;
      navigator.clipboard.writeText(txt).then(() => {
        alert('REST API 호출 스니펫이 클립보드에 복사되었습니다.');
      });
    }

    let currentStatusFilter = 'ALL';

    function setQuickDate(type) {
      const today = new Date();
      let startDate = new Date();

      if (type === 'today') {
        // 미국 시차(한국 오전 = 미국 전날 저녁)를 감안하여 최근 2일(어제~오늘) 자동 지정
        startDate.setDate(today.getDate() - 1);
      } else if (type === '3days') {
        startDate.setDate(today.getDate() - 2);
      } else if (type === 'week') {
        startDate.setDate(today.getDate() - 6);
      } else if (type === 'month') {
        startDate.setMonth(today.getMonth() - 1);
      }

      const formatDate = (d) => d.toISOString().split('T')[0];
      document.getElementById('startDate').value = formatDate(startDate);
      document.getElementById('endDate').value = formatDate(today);
      document.getElementById('exportModalStart').value = formatDate(startDate);
      document.getElementById('exportModalEnd').value = formatDate(today);
    }

    async function triggerSyncLatest() {
      const btn = document.getElementById('btnSyncLatest');
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> 최신 경기 자동 수집 중...';

      try {
        const today = new Date();
        const pastDate = new Date();
        // 시차 및 방금 끝난 경기 반영을 위해 최근 3일 범위 수집
        pastDate.setDate(today.getDate() - 3);
        const formatDate = (d) => d.toISOString().split('T')[0];
        const startStr = formatDate(pastDate);
        const endStr = formatDate(today);

        let league = document.getElementById('selectLeague').value;
        if (!league || league === 'ALL') league = 'KBO';

        document.getElementById('startDate').value = startStr;
        document.getElementById('endDate').value = endStr;

        const res = await fetch('/api/v1/matches/sync', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            league_id: league,
            start_date: startStr,
            end_date: endStr
          })
        });

        if (res.ok) {
          await loadMatches();
          const target = currentMatches.find(m => m.status === 'FINISHED') || currentMatches[0];

          if (target) {
            await selectMatch(target.id, document.getElementById(`matchCard_${target.id}`));
            alert(`[공식 ${league} 실시간 수집 성공!]\n방금 끝난 [${target.away_team_name} vs ${target.home_team_name}] (${target.match_date})\n1회부터 9회(연장)까지의 전광판 스코어보드와 타자 9명, 투수 전원 공식 기록이 화면에 반영되었습니다!`);
          }
        } else {
          alert('수집 중 오류가 발생했습니다.');
        }
      } catch (err) {
        console.error(err);
        alert('서버 연결 실패');
      } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="bi bi-lightning-charge-fill me-1"></i> 방금 끝난 경기 즉시 자동 수집';
      }
    }

    async function triggerSync() {
      const league = document.getElementById('selectLeague').value;
      const start = document.getElementById('startDate').value;
      const end = document.getElementById('endDate').value;
      const btn = document.getElementById('btnSync');

      btn.disabled = true;
      btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> 수집 진행 중...';

      try {
        const targetLeague = (league === 'ALL') ? 'MLB' : league;
        const res = await fetch('/api/v1/matches/sync', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            league_id: targetLeague,
            start_date: start,
            end_date: end
          })
        });

        if (res.ok) {
          const data = await res.json();
          alert(`[야구 데이터 수집 완료] 총 ${data.synced_matches_count}개의 경기 데이터가 성공적으로 동기화되었습니다.`);
          loadMatches();
        } else {
          alert('수집 중 오류가 발생했습니다.');
        }
      } catch (err) {
        console.error(err);
        alert('서버 연결 실패');
      } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="bi bi-cloud-arrow-down-fill me-1"></i> 기간 야구 데이터 일괄 수집';
      }
    }

    async function loadMatches() {
      const league = document.getElementById('selectLeague').value;
      const start = document.getElementById('startDate').value;
      const end = document.getElementById('endDate').value;
      const listEl = document.getElementById('matchesList');
      const countEl = document.getElementById('matchCountBadge');

      let url = `/api/v1/matches/?sport_code=BASEBALL&start_date=${start}&end_date=${end}`;
      if (league !== 'ALL') {
        url += `&league_name=${league}`;
      }

      listEl.innerHTML = `
        <div class="text-center py-5 text-muted">
          <div class="spinner-border spinner-border-sm mb-2"></div>
          <div>야구 경기 목록을 조회 중입니다...</div>
        </div>
      `;

      try {
        const res = await fetch(url);
        currentMatches = await res.json();
        filterMatches();

        if (currentMatches.length > 0) {
          const anyFinished = currentMatches.find(m => m.status === 'FINISHED');
          const anyLive = currentMatches.find(m => m.status === 'LIVE');
          const pick = anyFinished || anyLive || currentMatches[0];
          selectMatch(pick.id, document.getElementById(`matchCard_${pick.id}`));
        }
      } catch (err) {
        console.error(err);
        listEl.innerHTML = '<div class="text-center py-5 text-danger">경기 목록 조회 실패</div>';
      }
    }

    function setStatusFilter(st) {
      currentStatusFilter = st;
      document.getElementById('filterStatusAll').className = st === 'ALL' ? 'btn btn-outline-primary active' : 'btn btn-outline-primary';
      document.getElementById('filterStatusFinished').className = st === 'FINISHED' ? 'btn btn-outline-success active' : 'btn btn-outline-success';
      document.getElementById('filterStatusScheduled').className = st === 'SCHEDULED' ? 'btn btn-outline-secondary active' : 'btn btn-outline-secondary';
      filterMatches();
    }

    function filterMatches() {
      const q = (document.getElementById('teamSearchInput').value || '').trim().toLowerCase();
      let filtered = currentMatches;

      if (currentStatusFilter !== 'ALL') {
        filtered = filtered.filter(m => m.status === currentStatusFilter);
      }

      if (q) {
        filtered = filtered.filter(m => 
          (m.home_team_name && m.home_team_name.toLowerCase().includes(q)) ||
          (m.away_team_name && m.away_team_name.toLowerCase().includes(q)) ||
          (m.stadium && m.stadium.toLowerCase().includes(q))
        );
      }

      renderMatchesList(filtered);
    }

    function renderMatchesList(matches) {
      const listEl = document.getElementById('matchesList');
      const countEl = document.getElementById('matchCountBadge');
      countEl.innerText = `${matches.length} 경기`;

      if (matches.length === 0) {
        listEl.innerHTML = `
          <div class="text-center py-5 text-muted">
            <i class="bi bi-calendar-x fs-1 d-block mb-2"></i>
            조건에 맞는 야구 경기가 없습니다.
          </div>
        `;
        return;
      }

      let html = '';
      matches.forEach(m => {
        const isFinished = m.status === 'FINISHED';
        const isLive = m.status === 'LIVE';
        const statusBadge = isFinished ? '<span class="badge bg-secondary">경기종료</span>' :
                            (isLive ? '<span class="badge bg-danger animate-pulse">LIVE</span>' : '<span class="badge bg-info text-dark">예정</span>');
        const customBadge = m.is_customized ? '<span class="badge bg-warning text-dark ms-1">수정됨</span>' : '';
        const isSelected = selectedMatch && (selectedMatch.id === m.id || (selectedMatch.match && selectedMatch.match.id === m.id)) ? 'active' : '';

        html += `
          <div class="card match-card mb-3 p-3 ${isSelected}" id="matchCard_${m.id}" onclick="selectMatch(${m.id}, this)">
            <div class="d-flex justify-content-between align-items-center mb-2">
              <span class="badge bg-light text-dark border">${m.league_name}</span>
              <span class="small text-muted">${m.match_date}</span>
              <div>${statusBadge}${customBadge}</div>
            </div>
            <div class="d-flex justify-content-between align-items-center my-1">
              <div class="fw-bold text-truncate" style="max-width: 42%; font-size: 1.05rem;">${m.home_team_name}</div>
              <div class="badge ${isFinished ? 'bg-dark' : 'bg-secondary'} px-3 py-2 text-white fs-6">${m.home_score} : ${m.away_score}</div>
              <div class="fw-bold text-truncate text-end" style="max-width: 42%; font-size: 1.05rem;">${m.away_team_name}</div>
            </div>
            <div class="text-muted small text-end mt-2">${m.stadium || '스타디움'}</div>
          </div>
        `;
      });
      listEl.innerHTML = html;
    }

    async function selectMatch(matchId, cardEl) {
      document.querySelectorAll('.match-card').forEach(c => c.classList.remove('active'));
      const activeEl = cardEl || document.getElementById(`matchCard_${matchId}`);
      if (activeEl) {
        activeEl.classList.add('active');
      }

      try {
        const [res, rollRes] = await Promise.all([
          fetch(`/api/v1/matches/${matchId}`),
          fetch(`/api/v1/analytics/matches/${matchId}/rolling?windows=3,5,7,10&days=3,5,7,10`)
        ]);
        if (!res.ok) return;
        selectedMatch = await res.json();
        if (rollRes.ok) {
          const rJson = await rollRes.json();
          currentMatchRolling = rJson.data || {};
        } else {
          currentMatchRolling = {};
        }

        document.getElementById('noMatchSelected').style.display = 'none';
        document.getElementById('matchDetailView').style.display = 'block';

        const m = selectedMatch.match || selectedMatch;
        document.getElementById('detailLeagueBadge').innerText = m.league_name;
        document.getElementById('detailTime').innerText = `${m.match_date} (${m.season} ${m.round_name || ''})`;
        document.getElementById('detailStadium').innerText = `경기장: ${m.stadium || '정보 없음'}`;
        document.getElementById('detailHomeTeam').innerText = m.home_team_name;
        document.getElementById('detailAwayTeam').innerText = m.away_team_name;
        document.getElementById('detailScore').innerText = `${m.home_score} : ${m.away_score}`;

        const isFinished = m.status === 'FINISHED';
        const isLive = m.status === 'LIVE';
        const stBadge = document.getElementById('detailStatusBadge');
        stBadge.className = isFinished ? 'badge bg-secondary' : (isLive ? 'badge bg-danger' : 'badge bg-info text-dark');
        stBadge.innerText = isFinished ? '종료 (FINISHED)' : (isLive ? '진행중 (LIVE)' : '예정 (SCHEDULED)');

        document.getElementById('editHomeScore').value = m.home_score;
        document.getElementById('editAwayScore').value = m.away_score;
        document.getElementById('editStatus').value = m.status;
        document.getElementById('scoreEditForm').style.display = 'none';

        renderScoreboard(selectedMatch.details?.period_scores);
        renderPlayers();
        renderEvents(selectedMatch.events);

        document.getElementById('apiJsonPreview').textContent = JSON.stringify(selectedMatch, null, 2);
      } catch (err) {
        console.error(err);
      }
    }

    function toggleEditMatchScore() {
      const form = document.getElementById('scoreEditForm');
      form.style.display = form.style.display === 'none' ? 'block' : 'none';
    }

    async function saveMatchScore() {
      if (!selectedMatch) return;
      const m = selectedMatch.match || selectedMatch;
      const mId = m.id;
      const hScore = parseInt(document.getElementById('editHomeScore').value);
      const aScore = parseInt(document.getElementById('editAwayScore').value);
      const status = document.getElementById('editStatus').value;

      try {
        const res = await fetch(`/api/v1/matches/${mId}/score`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ home_score: hScore, away_score: aScore, status: status })
        });
        if (res.ok) {
          alert('경기 스코어가 성공적으로 저장 및 앱에 반영되었습니다.');
          selectMatch(mId);
          loadMatches();
        }
      } catch (err) {
        alert('저장 실패');
      }
    }

    function renderScoreboard(scores) {
      const el = document.getElementById('scoreboardTable');
      if (!scores || !scores.innings) {
        el.innerHTML = '<tr><td class="text-muted py-3">이닝별 스코어 정보가 없습니다.</td></tr>';
        return;
      }

      const m = selectedMatch.match || selectedMatch;
      const innings = scores.innings;
      const summary = scores.summary || {
        home: { R: m.home_score, H: 0, E: 0, B: 0 },
        away: { R: m.away_score, H: 0, E: 0, B: 0 }
      };

      const inKeys = Object.keys(innings).sort((a, b) => parseInt(a) - parseInt(b));

      let thHtml = '<tr><th style="width: 140px;">팀 명</th>';
      inKeys.forEach(k => { thHtml += `<th>${k}</th>`; });
      thHtml += '<th class="scoreboard-total text-danger">R</th><th class="scoreboard-total">H</th><th class="scoreboard-total">E</th><th class="scoreboard-total">B</th></tr>';

      // 초공 (Away) 먼저 표시
      let awayHtml = `<tr><td class="fw-bold text-start ps-3">${m.away_team_name} (원정)</td>`;
      inKeys.forEach(k => {
        const v = innings[k].away !== undefined ? innings[k].away : '-';
        awayHtml += `<td>${v}</td>`;
      });
      awayHtml += `<td class="scoreboard-total text-danger fw-bold fs-6">${summary.away.R}</td>`;
      awayHtml += `<td class="scoreboard-total">${summary.away.H}</td>`;
      awayHtml += `<td class="scoreboard-total">${summary.away.E}</td>`;
      awayHtml += `<td class="scoreboard-total">${summary.away.B}</td></tr>`;

      // 말공 (Home)
      let homeHtml = `<tr><td class="fw-bold text-start ps-3">${m.home_team_name} (홈)</td>`;
      inKeys.forEach(k => {
        const v = innings[k].home !== undefined ? innings[k].home : '-';
        homeHtml += `<td>${v}</td>`;
      });
      homeHtml += `<td class="scoreboard-total text-danger fw-bold fs-6">${summary.home.R}</td>`;
      homeHtml += `<td class="scoreboard-total">${summary.home.H}</td>`;
      homeHtml += `<td class="scoreboard-total">${summary.home.E}</td>`;
      homeHtml += `<td class="scoreboard-total">${summary.home.B}</td></tr>`;

      el.innerHTML = `<thead>${thHtml}</thead><tbody>${awayHtml}${homeHtml}</tbody>`;
    }

    function setStatMode(mode) {
      statMode = mode;
      const btnC = document.getElementById('btnModeClassic');
      const btnS = document.getElementById('btnModeSaber');
      if (btnC) btnC.className = mode === 'CLASSIC' ? 'btn btn-primary active fw-semibold' : 'btn btn-outline-dark fw-semibold';
      if (btnS) btnS.className = mode === 'SABER' ? 'btn btn-dark active fw-semibold' : 'btn btn-outline-dark fw-semibold';
      renderPlayers();
    }

    function setStatWindow(w) {
      statWindow = w;
      [3, 5, 7, 10].forEach(num => {
        const btn = document.getElementById(`btnWin${num}`);
        if (btn) btn.className = num === w ? 'btn btn-primary active' : 'btn btn-outline-primary';
      });
      renderPlayers();
    }

    function setStatUnit(u) {
      statUnit = u;
      const btnG = document.getElementById('btnUnitGames');
      const btnD = document.getElementById('btnUnitDays');
      if (btnG) btnG.className = u === 'games' ? 'btn btn-secondary active' : 'btn btn-outline-secondary';
      if (btnD) btnD.className = u === 'days' ? 'btn btn-secondary active' : 'btn btn-outline-secondary';
      renderPlayers();
    }

    function filterPlayerTeam(teamFilter) {
      playerFilter = teamFilter;
      document.getElementById('btnFilterAll').className = teamFilter === 'ALL' ? 'btn btn-sm btn-primary active' : 'btn btn-sm btn-outline-primary';
      document.getElementById('btnFilterHome').className = teamFilter === 'HOME' ? 'btn btn-sm btn-primary active' : 'btn btn-sm btn-outline-primary';
      document.getElementById('btnFilterAway').className = teamFilter === 'AWAY' ? 'btn btn-sm btn-primary active' : 'btn btn-sm btn-outline-primary';
      renderPlayers();
    }

    function renderPlayers() {
      if (!selectedMatch || !selectedMatch.player_stats) return;
      const m = selectedMatch.match || selectedMatch;
      const allPlayers = selectedMatch.player_stats;
      const homeTeam = m.home_team_name;
      const awayTeam = m.away_team_name;

      let filtered = allPlayers;
      if (playerFilter === 'HOME') filtered = allPlayers.filter(p => p.team_name === homeTeam);
      if (playerFilter === 'AWAY') filtered = allPlayers.filter(p => p.team_name === awayTeam);

      const hittersHead = document.getElementById('hittersThead');
      const pitchersHead = document.getElementById('pitchersThead');
      const hittersBody = document.getElementById('hittersTableBody');
      const pitchersBody = document.getElementById('pitchersTableBody');

      const unitBadge = statUnit === 'games' ? `${statWindow}G` : `${statWindow}일`;

      if (statMode === 'CLASSIC') {
        hittersHead.innerHTML = `
          <tr>
            <th style="width: 50px;">팀</th>
            <th style="width: 70px;">포지션</th>
            <th style="width: 60px;">등번호</th>
            <th>선수명</th>
            <th>타수</th>
            <th>득점</th>
            <th>안타</th>
            <th>2루타</th>
            <th>3루타</th>
            <th>홈런</th>
            <th>타점</th>
            <th>볼넷</th>
            <th>삼진</th>
            <th>도루</th>
            <th>AVG</th>
            <th>OPS</th>
            <th class="bg-primary-subtle text-primary fw-bold text-center">최근 ${unitBadge} 평균</th>
            <th style="width: 60px;">관리</th>
          </tr>
        `;
        pitchersHead.innerHTML = `
          <tr>
            <th style="width: 50px;">팀</th>
            <th style="width: 70px;">포지션</th>
            <th style="width: 60px;">등번호</th>
            <th>선수명</th>
            <th>이닝(IP)</th>
            <th>투구수</th>
            <th>피안타</th>
            <th>실점</th>
            <th>자책</th>
            <th>4사구</th>
            <th>탈삼진</th>
            <th>피홈런</th>
            <th>ERA</th>
            <th>WHIP</th>
            <th class="bg-primary-subtle text-primary fw-bold text-center">최근 ${unitBadge} 평균</th>
            <th>결과</th>
            <th style="width: 60px;">관리</th>
          </tr>
        `;
      } else {
        hittersHead.innerHTML = `
          <tr class="table-dark">
            <th style="width: 50px;">팀</th>
            <th style="width: 70px;">포지션</th>
            <th style="width: 60px;">등번호</th>
            <th>선수명</th>
            <th title="조정 득점 생산력 (wRC+, 리그 평균 100)" class="text-warning">wRC+</th>
            <th title="대체선수 대비 승리 기여도 (WAR)" class="text-warning">WAR</th>
            <th title="가중 출루율 (Weighted On-Base Average)">wOBA</th>
            <th title="순수 장타율 (Isolated Power)">ISO</th>
            <th title="인플레이 타구 타율 (Batting Average on Balls In Play)">BABIP</th>
            <th title="득점 기여도 (Runs Created)">RC</th>
            <th title="평균 대비 득점 생산력 (Weighted Runs Above Average)">wRAA</th>
            <th title="종합 타격 지수 (Gross Production Average)">GPA</th>
            <th title="평균 타구 속도 (Statcast Exit Velocity)" class="text-info">타구속도</th>
            <th title="평균 발사 각도 (Statcast Launch Angle)" class="text-info">발사각</th>
            <th title="배럴 타구율 (Statcast Barrel %)" class="text-info">배럴%</th>
            <th title="수비 실점 방어 (DRS)" class="text-success">DRS</th>
            <th title="평균 대비 아웃 카운트 (OAA)" class="text-success">OAA</th>
            <th title="볼넷 비율">BB%</th>
            <th title="삼진 비율">K%</th>
            <th class="bg-warning-subtle text-dark fw-bold text-center">최근 ${unitBadge} 세이버</th>
            <th style="width: 60px;">관리</th>
          </tr>
        `;
        pitchersHead.innerHTML = `
          <tr class="table-dark">
            <th style="width: 50px;">팀</th>
            <th style="width: 70px;">포지션</th>
            <th style="width: 60px;">등번호</th>
            <th>선수명</th>
            <th title="대체선수 대비 승리 기여도 (WAR)" class="text-warning">WAR</th>
            <th title="수비 무관 평균자책점 (Fielding Independent Pitching)">FIP</th>
            <th title="수비 무관 컴포넌트 ERA (Defense-Independent Component ERA)">DICE</th>
            <th title="이닝당 출루 허용율">WHIP</th>
            <th title="탈삼진율 - 볼넷율">K-BB%</th>
            <th title="헛스윙 유도율 (Statcast SwStr%)" class="text-info">헛스윙%</th>
            <th title="구종 억제 득점 가치 (Run Value)" class="text-info">구종가치</th>
            <th title="피타구 평균 속도 (Opp Avg EV)">피타구속도</th>
            <th title="피배럴 타구율 (Opp Barrel%)">피배럴%</th>
            <th title="피안타 BABIP">피BABIP</th>
            <th title="잔루율 (Left On Base %)">LOB%</th>
            <th title="9이닝당 탈삼진">K/9</th>
            <th title="9이닝당 볼넷">BB/9</th>
            <th>ERA</th>
            <th class="bg-warning-subtle text-dark fw-bold text-center">최근 ${unitBadge} 세이버</th>
            <th style="width: 60px;">관리</th>
          </tr>
        `;
      }

      let hittersHtml = '';
      let pitchersHtml = '';

      filtered.forEach(p => {
        const extra = p.extra_stats || {};
        const isPitcher = extra.type === 'PITCHER' || (p.position && p.position.includes('P'));
        const overrideBadge = p.is_override ? '<span class="badge bg-warning text-dark ms-1">수정</span>' : '';
        const teamBadge = p.team_name === homeTeam ? '<span class="badge bg-primary-subtle text-primary border">홈</span>' : '<span class="badge bg-danger-subtle text-danger border">원정</span>';

        const pAnalytics = currentMatchRolling[p.id] || {};
        const sMetrics = pAnalytics.sabermetrics || {};
        const unitDict = statUnit === 'games' ? (sMetrics.by_games || {}) : (sMetrics.by_days || {});
        const unitKey = statUnit === 'games' ? `${statWindow}G` : `${statWindow}D`;
        const sStat = unitDict[unitKey];

        if (isPitcher) {
          let saberFip = '-', saberDice = '-', saberWhip = '-', saberKBBPct = '-', saberOppBabip = '-', saberLobPct = '-';
          let saberK9 = '-', saberBB9 = '-', saberHR9 = '-', saberKBB = '-', saberEra = '-';
          let saberWar = '-', saberSwStr = '-', saberRV = '-', saberOppEV = '-', saberOppBarrel = '-';
          let saberTrend = 'NORMAL';

          if (sStat) {
            saberFip = sStat.fip !== undefined ? Number(sStat.fip).toFixed(2) : '-';
            saberDice = sStat.dice !== undefined ? Number(sStat.dice).toFixed(2) : '-';
            saberWhip = sStat.whip !== undefined ? Number(sStat.whip).toFixed(2) : '-';
            saberKBBPct = sStat.k_bb_pct !== undefined ? Number(sStat.k_bb_pct).toFixed(1) + '%' : '-';
            saberOppBabip = sStat.opp_babip !== undefined ? Number(sStat.opp_babip).toFixed(3) : '-';
            saberLobPct = sStat.lob_pct !== undefined ? Number(sStat.lob_pct).toFixed(1) + '%' : '-';
            saberK9 = sStat.k9 !== undefined ? Number(sStat.k9).toFixed(1) : '-';
            saberBB9 = sStat.bb9 !== undefined ? Number(sStat.bb9).toFixed(1) : '-';
            saberHR9 = sStat.hr9 !== undefined ? Number(sStat.hr9).toFixed(1) : '-';
            saberKBB = sStat.k_bb !== undefined ? Number(sStat.k_bb).toFixed(2) : '-';
            saberEra = sStat.era !== undefined ? Number(sStat.era).toFixed(2) : '-';
            saberWar = sStat.war !== undefined ? sStat.war : '-';
            saberSwStr = sStat.swstr_pct !== undefined ? sStat.swstr_pct : '-';
            saberRV = sStat.run_value !== undefined ? sStat.run_value : '-';
            saberOppEV = sStat.exit_velocity_opp !== undefined ? sStat.exit_velocity_opp : '-';
            saberOppBarrel = sStat.barrel_pct_opp !== undefined ? sStat.barrel_pct_opp : '-';
            saberTrend = sStat.trend || 'NORMAL';
          }

          let rollBadge = '';
          if (statMode === 'CLASSIC') {
            const dispEra = saberEra !== '-' ? saberEra : (extra.era || '-');
            const dispIp = sStat?.ip !== undefined ? `${sStat.ip}이닝` : '';
            if (saberTrend === 'DOMINANT') {
              rollBadge = `<span class="badge bg-primary text-white cursor-pointer fw-bold shadow-sm" onclick="showPlayerTrendModal('${p.player_name}', 'pitcher', '${p.team_name}')">⚡ ${dispEra} (${dispIp})</span>`;
            } else if (saberTrend === 'STRUGGLING') {
              rollBadge = `<span class="badge bg-danger text-white cursor-pointer" onclick="showPlayerTrendModal('${p.player_name}', 'pitcher', '${p.team_name}')">⚠️ ${dispEra}</span>`;
            } else {
              rollBadge = `<span class="badge bg-light text-dark border cursor-pointer" onclick="showPlayerTrendModal('${p.player_name}', 'pitcher', '${p.team_name}')">${dispEra}</span>`;
            }
          } else {
            if (saberTrend === 'DOMINANT') {
              rollBadge = `<span class="badge bg-primary text-white cursor-pointer fw-bold shadow-sm" onclick="showPlayerTrendModal('${p.player_name}', 'pitcher', '${p.team_name}')">⚡ FIP ${saberFip}</span>`;
            } else if (saberTrend === 'STRUGGLING') {
              rollBadge = `<span class="badge bg-danger text-white cursor-pointer" onclick="showPlayerTrendModal('${p.player_name}', 'pitcher', '${p.team_name}')">⚠️ FIP ${saberFip}</span>`;
            } else {
              rollBadge = `<span class="badge bg-warning-subtle text-dark border cursor-pointer fw-bold" onclick="showPlayerTrendModal('${p.player_name}', 'pitcher', '${p.team_name}')">FIP ${saberFip}</span>`;
            }
          }

          if (statMode === 'CLASSIC') {
            pitchersHtml += `
              <tr>
                <td>${teamBadge}</td>
                <td><span class="badge bg-light text-dark border">${p.position || '투수'}</span></td>
                <td>${p.back_number || '-'}</td>
                <td class="fw-bold cursor-pointer text-primary" onclick="showPlayerTrendModal('${p.player_name}', 'pitcher', '${p.team_name}')">${p.player_name}${overrideBadge}</td>
                <td class="fw-semibold text-primary">${extra.ip || '-'}</td>
                <td>${extra.np || '-'}</td>
                <td>${extra.h !== undefined ? extra.h : '-'}</td>
                <td>${extra.r !== undefined ? extra.r : '-'}</td>
                <td>${extra.er !== undefined ? extra.er : '-'}</td>
                <td>${extra.bb !== undefined ? extra.bb : '-'}</td>
                <td class="text-danger fw-bold">${extra.so !== undefined ? extra.so : p.points}</td>
                <td>${extra.hr !== undefined ? extra.hr : '-'}</td>
                <td>${extra.era || '-'}</td>
                <td>${extra.whip || '-'}</td>
                <td class="text-center">${rollBadge}</td>
                <td><span class="badge bg-secondary-subtle text-secondary">${extra.decision || '-'}</span></td>
                <td>
                  <button class="btn btn-sm btn-outline-primary" onclick="openPlayerEditModal(${p.id})">
                    <i class="bi bi-pencil-fill"></i>
                  </button>
                </td>
              </tr>
            `;
          } else {
            pitchersHtml += `
              <tr>
                <td>${teamBadge}</td>
                <td><span class="badge bg-light text-dark border">${p.position || '투수'}</span></td>
                <td>${p.back_number || '-'}</td>
                <td class="fw-bold cursor-pointer text-primary" onclick="showPlayerTrendModal('${p.player_name}', 'pitcher', '${p.team_name}')">${p.player_name}${overrideBadge}</td>
                <td class="fw-bold text-warning-emphasis">${saberWar}</td>
                <td class="fw-bold text-danger">${saberFip}</td>
                <td>${saberDice}</td>
                <td class="fw-semibold">${saberWhip}</td>
                <td class="fw-bold text-primary">${saberKBBPct}</td>
                <td class="text-info-emphasis fw-bold">${saberSwStr}</td>
                <td class="fw-semibold">${saberRV}</td>
                <td>${saberOppEV}</td>
                <td>${saberOppBarrel}</td>
                <td>${saberOppBabip}</td>
                <td>${saberLobPct}</td>
                <td>${saberK9}</td>
                <td>${saberBB9}</td>
                <td>${saberEra !== '-' ? saberEra : (extra.era || '-')}</td>
                <td class="text-center">${rollBadge}</td>
                <td>
                  <button class="btn btn-sm btn-outline-primary" onclick="openPlayerEditModal(${p.id})">
                    <i class="bi bi-pencil-fill"></i>
                  </button>
                </td>
              </tr>
            `;
          }
        } else {
          let sWoba = '-', sIso = '-', sBabip = '-', sRc = '-', sWraa = '-', sGpa = '-';
          let sBbPct = '-', sKPct = '-', sBbK = '-', sOps = '-', sAvg = '-';
          let sWrcPlus = '-', sWar = '-', sEV = '-', sLA = '-', sBarrel = '-', sDrs = '-', sOaa = '-';
          let sTrend = 'NORMAL';

          if (sStat) {
            sWoba = sStat.woba !== undefined ? Number(sStat.woba).toFixed(3) : '-';
            sIso = sStat.iso !== undefined ? Number(sStat.iso).toFixed(3) : '-';
            sBabip = sStat.babip !== undefined ? Number(sStat.babip).toFixed(3) : '-';
            sRc = sStat.rc !== undefined ? Number(sStat.rc).toFixed(1) : '-';
            sWraa = sStat.wraa !== undefined ? (sStat.wraa > 0 ? '+' : '') + Number(sStat.wraa).toFixed(1) : '-';
            sGpa = sStat.gpa !== undefined ? Number(sStat.gpa).toFixed(3) : '-';
            sBbPct = sStat.bb_pct !== undefined ? Number(sStat.bb_pct).toFixed(1) + '%' : '-';
            sKPct = sStat.k_pct !== undefined ? Number(sStat.k_pct).toFixed(1) + '%' : '-';
            sBbK = sStat.bb_k !== undefined ? Number(sStat.bb_k).toFixed(2) : '-';
            sOps = sStat.ops !== undefined ? Number(sStat.ops).toFixed(3) : '-';
            sAvg = sStat.avg !== undefined ? Number(sStat.avg).toFixed(3) : '-';
            sWrcPlus = sStat.wrc_plus !== undefined ? sStat.wrc_plus : '-';
            sWar = sStat.war !== undefined ? sStat.war : '-';
            sEV = sStat.exit_velocity !== undefined ? sStat.exit_velocity : '-';
            sLA = sStat.launch_angle !== undefined ? sStat.launch_angle : '-';
            sBarrel = sStat.barrel_pct !== undefined ? sStat.barrel_pct : '-';
            sDrs = sStat.drs !== undefined ? sStat.drs : '-';
            sOaa = sStat.oaa !== undefined ? sStat.oaa : '-';
            sTrend = sStat.trend || 'NORMAL';
          }

          let rollBadge = '';
          if (statMode === 'CLASSIC') {
            const dispAvg = sAvg !== '-' ? sAvg : (extra.avg || '-');
            const dispHr = sStat?.hr !== undefined ? `${sStat.hr}HR` : '';
            if (sTrend === 'HOT') {
              rollBadge = `<span class="badge bg-danger text-white cursor-pointer fw-bold shadow-sm" onclick="showPlayerTrendModal('${p.player_name}', 'hitter', '${p.team_name}')">🔥 ${dispAvg} (${dispHr})</span>`;
            } else if (sTrend === 'COLD') {
              rollBadge = `<span class="badge bg-info-subtle text-primary border border-info-subtle cursor-pointer" onclick="showPlayerTrendModal('${p.player_name}', 'hitter', '${p.team_name}')">❄️ ${dispAvg}</span>`;
            } else {
              rollBadge = `<span class="badge bg-light text-dark border cursor-pointer" onclick="showPlayerTrendModal('${p.player_name}', 'hitter', '${p.team_name}')">${dispAvg}</span>`;
            }
          } else {
            if (sTrend === 'HOT') {
              rollBadge = `<span class="badge bg-danger text-white cursor-pointer fw-bold shadow-sm" onclick="showPlayerTrendModal('${p.player_name}', 'hitter', '${p.team_name}')">🔥 wOBA ${sWoba}</span>`;
            } else if (sTrend === 'COLD') {
              rollBadge = `<span class="badge bg-secondary-subtle text-muted border cursor-pointer" onclick="showPlayerTrendModal('${p.player_name}', 'hitter', '${p.team_name}')">❄️ wOBA ${sWoba}</span>`;
            } else {
              rollBadge = `<span class="badge bg-warning-subtle text-dark border cursor-pointer fw-bold" onclick="showPlayerTrendModal('${p.player_name}', 'hitter', '${p.team_name}')">wOBA ${sWoba}</span>`;
            }
          }

          if (statMode === 'CLASSIC') {
            hittersHtml += `
              <tr>
                <td>${teamBadge}</td>
                <td><span class="badge bg-light text-dark border">${p.position || '타자'}</span></td>
                <td>${p.back_number || '-'}</td>
                <td class="fw-bold cursor-pointer text-primary" onclick="showPlayerTrendModal('${p.player_name}', 'hitter', '${p.team_name}')">${p.player_name}${overrideBadge}</td>
                <td>${extra.ab !== undefined ? extra.ab : p.shots}</td>
                <td>${extra.r !== undefined ? extra.r : '-'}</td>
                <td class="text-primary fw-bold">${extra.h !== undefined ? extra.h : '-'}</td>
                <td>${extra['2b'] !== undefined ? extra['2b'] : '-'}</td>
                <td>${extra['3b'] !== undefined ? extra['3b'] : '-'}</td>
                <td class="text-danger fw-bold">${extra.hr !== undefined ? extra.hr : '-'}</td>
                <td class="text-success fw-bold">${extra.rbi !== undefined ? extra.rbi : p.points}</td>
                <td>${extra.bb !== undefined ? extra.bb : '-'}</td>
                <td>${extra.so !== undefined ? extra.so : '-'}</td>
                <td>${extra.sb !== undefined ? extra.sb : '-'}</td>
                <td>${extra.avg || '-'}</td>
                <td class="fw-semibold">${extra.ops || '-'}</td>
                <td class="text-center">${rollBadge}</td>
                <td>
                  <button class="btn btn-sm btn-outline-primary" onclick="openPlayerEditModal(${p.id})">
                    <i class="bi bi-pencil-fill"></i>
                  </button>
                </td>
              </tr>
            `;
          } else {
            hittersHtml += `
              <tr>
                <td>${teamBadge}</td>
                <td><span class="badge bg-light text-dark border">${p.position || '타자'}</span></td>
                <td>${p.back_number || '-'}</td>
                <td class="fw-bold cursor-pointer text-primary" onclick="showPlayerTrendModal('${p.player_name}', 'hitter', '${p.team_name}')">${p.player_name}${overrideBadge}</td>
                <td class="fw-bold text-warning-emphasis">${sWrcPlus}</td>
                <td class="fw-bold text-success-emphasis">${sWar}</td>
                <td class="fw-bold text-danger">${sWoba}</td>
                <td class="fw-semibold">${sIso}</td>
                <td>${sBabip}</td>
                <td class="fw-bold text-primary">${sRc}</td>
                <td>${sWraa}</td>
                <td>${sGpa}</td>
                <td class="text-info-emphasis">${sEV}</td>
                <td>${sLA}</td>
                <td class="fw-bold text-danger-emphasis">${sBarrel}</td>
                <td class="text-success fw-semibold">${sDrs}</td>
                <td class="text-success fw-semibold">${sOaa}</td>
                <td>${sBbPct}</td>
                <td>${sKPct}</td>
                <td class="text-center">${rollBadge}</td>
                <td>
                  <button class="btn btn-sm btn-outline-primary" onclick="openPlayerEditModal(${p.id})">
                    <i class="bi bi-pencil-fill"></i>
                  </button>
                </td>
              </tr>
            `;
          }
        }
      });

      hittersBody.innerHTML = hittersHtml || '<tr><td colspan="21" class="text-muted py-3">타자 명단이 없습니다.</td></tr>';
      pitchersBody.innerHTML = pitchersHtml || '<tr><td colspan="20" class="text-muted py-3">투수 명단이 없습니다.</td></tr>';
    }

    function renderEvents(events) {
      const el = document.getElementById('eventsTimeline');
      if (!events || events.length === 0) {
        el.innerHTML = '<div class="text-muted small">기록된 주요 상황 이벤트가 없습니다.</div>';
        return;
      }

      let html = '<div class="list-group list-group-flush">';
      events.forEach(ev => {
        const isHr = ev.event_type === 'HOMERUN';
        const icon = isHr ? '💥' : '⚾';
        const badgeColor = isHr ? 'bg-danger' : 'bg-primary';

        html += `
          <div class="list-group-item px-0 py-2 d-flex justify-content-between align-items-center">
            <div>
              <span class="badge ${badgeColor} me-2">${ev.time_display}</span>
              <span class="fw-bold me-2">${icon} [${ev.team_name}] ${ev.player_name}</span>
              <span class="text-muted small">${ev.description || ''}</span>
            </div>
            <div>
              <span class="badge bg-light text-dark border fw-bold">${ev.score_after || ''}</span>
            </div>
          </div>
        `;
      });
      html += '</div>';
      el.innerHTML = html;
    }

    function openPlayerEditModal(statId) {
      const p = selectedMatch.player_stats.find(item => item.id === statId);
      if (!p) return;

      document.getElementById('modalStatId').value = statId;
      const extra = p.extra_stats || {};
      const isPitcher = extra.type === 'PITCHER' || (p.position && p.position.includes('P'));
      document.getElementById('modalPlayerType').value = isPitcher ? 'PITCHER' : 'HITTER';

      document.getElementById('playerModalTitle').innerHTML = `<i class="bi bi-pencil-square me-2"></i>[${p.team_name}] ${p.player_name} (${p.position}) 기록 수정`;
      document.getElementById('editReason').value = p.override_reason || '';

      if (isPitcher) {
        document.getElementById('hitterEditFields').style.display = 'none';
        document.getElementById('pitcherEditFields').style.display = 'block';

        document.getElementById('editPitcherIP').value = extra.ip || '6.0';
        document.getElementById('editPitcherNP').value = extra.np || 90;
        document.getElementById('editPitcherH').value = extra.h || 5;
        document.getElementById('editPitcherR').value = extra.r || 2;
        document.getElementById('editPitcherER').value = extra.er || 2;
        document.getElementById('editPitcherBB').value = extra.bb || 2;
        document.getElementById('editPitcherSO').value = extra.so || p.points;
        document.getElementById('editPitcherHR').value = extra.hr || 1;
        document.getElementById('editPitcherERA').value = extra.era || '2.92';
        document.getElementById('editPitcherWHIP').value = extra.whip || '1.08';
        document.getElementById('editPitcherDecision').value = extra.decision || '승리투수 (W)';
      } else {
        document.getElementById('hitterEditFields').style.display = 'block';
        document.getElementById('pitcherEditFields').style.display = 'none';

        document.getElementById('editHitterAB').value = extra.ab !== undefined ? extra.ab : p.shots;
        document.getElementById('editHitterR').value = extra.r !== undefined ? extra.r : 1;
        document.getElementById('editHitterH').value = extra.h !== undefined ? extra.h : 2;
        document.getElementById('editHitter2B').value = extra['2b'] !== undefined ? extra['2b'] : 0;
        document.getElementById('editHitter3B').value = extra['3b'] !== undefined ? extra['3b'] : 0;
        document.getElementById('editHitterHR').value = extra.hr !== undefined ? extra.hr : 1;
        document.getElementById('editHitterRBI').value = extra.rbi !== undefined ? extra.rbi : p.points;
        document.getElementById('editHitterBB').value = extra.bb !== undefined ? extra.bb : 1;
        document.getElementById('editHitterSO').value = extra.so !== undefined ? extra.so : 0;
        document.getElementById('editHitterSB').value = extra.sb !== undefined ? extra.sb : 0;
        document.getElementById('editHitterAVG').value = extra.avg || '0.312';
        document.getElementById('editHitterOPS').value = extra.ops || '1.045';
      }

      editModalObj.show();
    }

    async function savePlayerStat() {
      const statId = parseInt(document.getElementById('modalStatId').value);
      const pType = document.getElementById('modalPlayerType').value;
      const reason = document.getElementById('editReason').value;

      let payload = {
        override_reason: reason,
        extra_stats: {}
      };

      if (pType === 'PITCHER') {
        const so = parseInt(document.getElementById('editPitcherSO').value) || 0;
        payload.points = so; // 투수의 경우 삼진 수
        payload.extra_stats = {
          type: 'PITCHER',
          ip: document.getElementById('editPitcherIP').value,
          np: parseInt(document.getElementById('editPitcherNP').value) || 0,
          h: parseInt(document.getElementById('editPitcherH').value) || 0,
          r: parseInt(document.getElementById('editPitcherR').value) || 0,
          er: parseInt(document.getElementById('editPitcherER').value) || 0,
          bb: parseInt(document.getElementById('editPitcherBB').value) || 0,
          so: so,
          hr: parseInt(document.getElementById('editPitcherHR').value) || 0,
          era: document.getElementById('editPitcherERA').value,
          whip: document.getElementById('editPitcherWHIP').value,
          decision: document.getElementById('editPitcherDecision').value
        };
      } else {
        const ab = parseInt(document.getElementById('editHitterAB').value) || 0;
        const rbi = parseInt(document.getElementById('editHitterRBI').value) || 0;
        payload.shots = ab;   // 타수의 경우 shots
        payload.points = rbi; // 타점의 경우 points
        payload.extra_stats = {
          type: 'HITTER',
          ab: ab,
          r: parseInt(document.getElementById('editHitterR').value) || 0,
          h: parseInt(document.getElementById('editHitterH').value) || 0,
          '2b': parseInt(document.getElementById('editHitter2B').value) || 0,
          '3b': parseInt(document.getElementById('editHitter3B').value) || 0,
          hr: parseInt(document.getElementById('editHitterHR').value) || 0,
          rbi: rbi,
          bb: parseInt(document.getElementById('editHitterBB').value) || 0,
          so: parseInt(document.getElementById('editHitterSO').value) || 0,
          sb: parseInt(document.getElementById('editHitterSB').value) || 0,
          avg: document.getElementById('editHitterAVG').value,
          ops: document.getElementById('editHitterOPS').value
        };
      }

      try {
        const res = await fetch(`/api/v1/matches/players/${statId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        if (res.ok) {
          editModalObj.hide();
          const m = selectedMatch.match || selectedMatch;
          selectMatch(m.id);
        } else {
          alert('선수 지표 수정 실패');
        }
      } catch (err) {
        console.error(err);
        alert('서버 오류');
      }
    }

    function openFolderExportModal() {
      document.getElementById('exportResultArea').style.display = 'none';
      folderModalObj.show();
    }

    async function executeFolderExport() {
      const league = document.getElementById('exportModalLeague').value;
      const start = document.getElementById('exportModalStart').value;
      const end = document.getElementById('exportModalEnd').value;
      const btn = document.getElementById('btnExecuteExport');

      btn.disabled = true;
      btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> 디스크 폴더 및 파일 생성 중...';

      try {
        const res = await fetch('/api/v1/content/export-folders', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            league_id: league,
            start_date: start,
            end_date: end
          })
        });

        if (res.ok) {
          const data = await res.json();
          const details = data.export_details || {};
          const manifest = details.manifest || {};
          const totalTeams = data.total_teams || manifest.total_teams || 30;
          const exportPath = data.export_path || details.export_root_dir || `exports/${league}`;
          const downloadUrl = data.download_url || `/api/v1/content/download-zip/${league}`;

          document.getElementById('exportResultArea').style.display = 'block';
          document.getElementById('exportResultText').innerHTML = 
            `<b>리그:</b> ${league} | <b>기간:</b> ${start} ~ ${end} | <b>총 구단:</b> ${totalTeams}개 팀 폴더 생성 완료<br><small class="text-muted">저장 위치: ${exportPath}</small>`;
          document.getElementById('btnDownloadZip').href = downloadUrl;
        } else {
          alert('폴더 내보내기 실패');
        }
      } catch (err) {
        console.error(err);
        alert('폴더 생성 중 오류: ' + (err.message || err));
      } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="bi bi-folder-plus me-1"></i>폴더 생성 실행하기';
      }
    }

    function setModalTrendUnit(u) {
      trendModalUnit = u;
      const btnG = document.getElementById('modalUnitGames');
      const btnD = document.getElementById('modalUnitDays');
      if (btnG) btnG.className = u === 'games' ? 'btn btn-primary active' : 'btn btn-outline-primary';
      if (btnD) btnD.className = u === 'days' ? 'btn btn-primary active' : 'btn btn-outline-primary';
      renderTrendModalCards();
    }

    function renderTrendModalCards() {
      const container = document.getElementById('trendCardsContainer');
      if (!container || !currentTrendPlayerData) return;

      const windows = [3, 5, 7, 10];
      const sMetrics = currentTrendPlayerData.sabermetrics || {};
      const unitDict = trendModalUnit === 'games' ? (sMetrics.by_games || {}) : (sMetrics.by_days || {});
      const isPitcher = currentTrendPlayerType === 'pitcher';

      let cardsHtml = '';

      windows.forEach(w => {
        const key = trendModalUnit === 'games' ? `${w}G` : `${w}D`;
        const title = trendModalUnit === 'games' ? `최근 ${w}경기` : `최근 ${w}일`;
        const stat = unitDict[key] || {};

        if (isPitcher) {
          const era = stat.era !== undefined ? Number(stat.era).toFixed(2) : '-';
          const fip = stat.fip !== undefined ? Number(stat.fip).toFixed(2) : '-';
          const whip = stat.whip !== undefined ? Number(stat.whip).toFixed(2) : '-';
          const kbbPct = stat.k_bb_pct !== undefined ? Number(stat.k_bb_pct).toFixed(1) + '%' : '-';
          const babip = stat.opp_babip !== undefined ? Number(stat.opp_babip).toFixed(3) : '-';
          const lob = stat.lob_pct !== undefined ? Number(stat.lob_pct).toFixed(1) + '%' : '-';
          const k9 = stat.k9 !== undefined ? Number(stat.k9).toFixed(1) : '-';
          const bb9 = stat.bb9 !== undefined ? Number(stat.bb9).toFixed(1) : '-';
          const ip = stat.ip !== undefined ? `${stat.ip}이닝` : '-';
          const so = stat.so !== undefined ? stat.so : 0;
          const war = stat.war !== undefined ? stat.war : '-';
          const swstr = stat.swstr_pct !== undefined ? stat.swstr_pct : '-';
          const rv = stat.run_value !== undefined ? stat.run_value : '-';
          const oppEv = stat.exit_velocity_opp !== undefined ? stat.exit_velocity_opp : '-';
          const oppBrl = stat.barrel_pct_opp !== undefined ? stat.barrel_pct_opp : '-';
          const trend = stat.trend || 'NORMAL';

          let trendBadge = '<span class="badge bg-secondary">보통</span>';
          let borderClass = 'border';
          if (trend === 'DOMINANT') {
            trendBadge = '<span class="badge bg-success">⚡ 짠물투</span>';
            borderClass = 'border-success border-2';
          } else if (trend === 'STRUGGLING') {
            trendBadge = '<span class="badge bg-danger">⚠️ 난조</span>';
            borderClass = 'border-danger border-2';
          }

          cardsHtml += `
            <div class="col-md-3 col-6">
              <div class="card h-100 shadow-sm ${borderClass}">
                <div class="card-header bg-light py-2 d-flex justify-content-between align-items-center">
                  <span class="fw-bold text-dark">${title}</span>
                  ${trendBadge}
                </div>
                <div class="card-body p-2 text-center">
                  <div class="row g-1 mb-2">
                    <div class="col-3">
                      <div class="text-muted" style="font-size: 0.68rem;">ERA</div>
                      <div class="fw-bold text-danger fs-6">${era}</div>
                    </div>
                    <div class="col-3">
                      <div class="text-muted" style="font-size: 0.68rem;">FIP</div>
                      <div class="fw-bold text-primary fs-6">${fip}</div>
                    </div>
                    <div class="col-3">
                      <div class="text-muted" style="font-size: 0.68rem;">WHIP</div>
                      <div class="fw-bold fs-6">${whip}</div>
                    </div>
                    <div class="col-3">
                      <div class="text-muted" style="font-size: 0.68rem;">WAR</div>
                      <div class="fw-bold text-warning-emphasis fs-6">${war}</div>
                    </div>
                  </div>
                  <div class="row g-1 mb-1 text-muted" style="font-size: 0.72rem;">
                    <div class="col-4">K-BB%: <b class="text-dark">${kbbPct}</b></div>
                    <div class="col-4">헛스윙%: <b class="text-primary">${swstr}</b></div>
                    <div class="col-4">구종가치: <b class="text-success">${rv}</b></div>
                  </div>
                  <div class="row g-1 mb-1 text-muted" style="font-size: 0.72rem;">
                    <div class="col-4">피타구속도: <b class="text-dark">${oppEv}</b></div>
                    <div class="col-4">피배럴%: <b class="text-dark">${oppBrl}</b></div>
                    <div class="col-4">잔루율: <b class="text-dark">${lob}</b></div>
                  </div>
                  <hr class="my-1">
                  <div class="small text-secondary" style="font-size: 0.72rem;">
                    ${ip} | 탈삼진: <b class="text-primary">${so}</b> | K/9: <b>${k9}</b> | 피BABIP: <b>${babip}</b>
                  </div>
                </div>
              </div>
            </div>
          `;
        } else {
          const avg = stat.avg !== undefined ? Number(stat.avg).toFixed(3) : '-';
          const woba = stat.woba !== undefined ? Number(stat.woba).toFixed(3) : '-';
          const ops = stat.ops !== undefined ? Number(stat.ops).toFixed(3) : '-';
          const iso = stat.iso !== undefined ? Number(stat.iso).toFixed(3) : '-';
          const babip = stat.babip !== undefined ? Number(stat.babip).toFixed(3) : '-';
          const rc = stat.rc !== undefined ? Number(stat.rc).toFixed(1) : '-';
          const wraa = stat.wraa !== undefined ? (stat.wraa > 0 ? '+' : '') + Number(stat.wraa).toFixed(1) : '-';
          const wrcPlus = stat.wrc_plus !== undefined ? stat.wrc_plus : '100';
          const war = stat.war !== undefined ? stat.war : '-';
          const ev = stat.exit_velocity !== undefined ? stat.exit_velocity : '-';
          const la = stat.launch_angle !== undefined ? stat.launch_angle : '-';
          const brl = stat.barrel_pct !== undefined ? stat.barrel_pct : '-';
          const drs = stat.drs !== undefined ? stat.drs : '0.0';
          const oaa = stat.oaa !== undefined ? stat.oaa : '0';
          const hits = stat.h !== undefined ? `${stat.h}안타` : '-';
          const hr = stat.hr !== undefined ? `${stat.hr}홈런` : '-';
          const rbi = stat.rbi !== undefined ? `${stat.rbi}타점` : '-';
          const trend = stat.trend || 'NORMAL';

          let trendBadge = '<span class="badge bg-secondary">보통</span>';
          let borderClass = 'border';
          if (trend === 'HOT') {
            trendBadge = '<span class="badge bg-danger">🔥 맹타</span>';
            borderClass = 'border-danger border-2';
          } else if (trend === 'COLD') {
            trendBadge = '<span class="badge bg-info-subtle text-primary border">❄️ 슬럼프</span>';
            borderClass = 'border-info border-2';
          }

          cardsHtml += `
            <div class="col-md-3 col-6">
              <div class="card h-100 shadow-sm ${borderClass}">
                <div class="card-header bg-light py-2 d-flex justify-content-between align-items-center">
                  <span class="fw-bold text-dark">${title}</span>
                  ${trendBadge}
                </div>
                <div class="card-body p-2 text-center">
                  <div class="row g-1 mb-2">
                    <div class="col-3">
                      <div class="text-muted" style="font-size: 0.68rem;">타율</div>
                      <div class="fw-bold text-danger fs-6">${avg}</div>
                    </div>
                    <div class="col-3">
                      <div class="text-muted" style="font-size: 0.68rem;">wRC+</div>
                      <div class="fw-bold text-warning-emphasis fs-6">${wrcPlus}</div>
                    </div>
                    <div class="col-3">
                      <div class="text-muted" style="font-size: 0.68rem;">wOBA</div>
                      <div class="fw-bold text-primary fs-6">${woba}</div>
                    </div>
                    <div class="col-3">
                      <div class="text-muted" style="font-size: 0.68rem;">WAR</div>
                      <div class="fw-bold text-success-emphasis fs-6">${war}</div>
                    </div>
                  </div>
                  <div class="row g-1 mb-1 text-muted" style="font-size: 0.72rem;">
                    <div class="col-3">OPS: <b class="text-dark">${ops}</b></div>
                    <div class="col-3">ISO: <b class="text-dark">${iso}</b></div>
                    <div class="col-3">BABIP: <b class="text-dark">${babip}</b></div>
                    <div class="col-3">RC: <b class="text-dark">${rc}</b></div>
                  </div>
                  <div class="row g-1 mb-1 text-muted" style="font-size: 0.72rem;">
                    <div class="col-4">타구속도: <b class="text-primary">${ev}</b></div>
                    <div class="col-4">발사각: <b class="text-dark">${la}</b></div>
                    <div class="col-4">배럴%: <b class="text-danger">${brl}</b></div>
                  </div>
                  <hr class="my-1">
                  <div class="small text-secondary" style="font-size: 0.72rem;">
                    ${hits} | ${hr} | ${rbi} | DRS: <b class="text-success">${drs}</b> | OAA: <b class="text-success">${oaa}</b>
                  </div>
                </div>
              </div>
            </div>
          `;
        }
      });

      container.innerHTML = cardsHtml;
    }

    async function showPlayerTrendModal(playerName, playerType, teamName) {
      if (!trendModalObj) {
        trendModalObj = new bootstrap.Modal(document.getElementById('playerTrendModal'));
      }
      currentTrendPlayerType = playerType;
      trendModalUnit = 'games';

      document.getElementById('modalUnitGames').className = 'btn btn-primary active';
      document.getElementById('modalUnitDays').className = 'btn btn-outline-primary';

      document.getElementById('trendModalTitle').innerHTML = 
        `<i class="bi bi-graph-up-arrow text-warning me-2"></i>[${teamName}] <b>${playerName}</b> 세이버메트릭스 & 정밀 롤링 지표 (${playerType === 'pitcher' ? '투수' : '타자'})`;
      
      document.getElementById('trendCardsContainer').innerHTML = 
        '<div class="col-12 py-4 text-center text-muted"><div class="spinner-border spinner-border-sm text-primary me-2"></div> 3G · 5G · 7G · 10G 세이버메트릭스 수치 정밀 연산 중...</div>';
      
      document.getElementById('trendLogsThead').innerHTML = '';
      document.getElementById('trendLogsTbody').innerHTML = '<tr><td colspan="13" class="py-3 text-muted">경기 기록 로딩 중...</td></tr>';
      
      trendModalObj.show();

      try {
        const res = await fetch(`/api/v1/analytics/players/${encodeURIComponent(playerName)}/rolling?player_type=${playerType}&team_name=${encodeURIComponent(teamName)}&windows=3,5,7,10&days=3,5,7,10`);
        if (!res.ok) {
          document.getElementById('trendCardsContainer').innerHTML = '<div class="col-12 py-3 text-muted text-center">기록이 부족합니다.</div>';
          return;
        }
        const resp = await res.json();
        const data = resp.data || {};
        currentTrendPlayerData = data;
        renderTrendModalCards();

        const logs = data.recent_game_logs || [];

        if (playerType === 'pitcher') {
          document.getElementById('trendLogsThead').innerHTML = `
            <tr><th>경기일</th><th>상대팀</th><th>이닝(IP)</th><th>투구수</th><th>피안타</th><th>실점</th><th>자책</th><th>4사구</th><th>탈삼진</th><th>피홈런</th><th>결과</th></tr>
          `;
          let logsHtml = '';
          logs.forEach(l => {
            logsHtml += `<tr>
              <td>${l.match_date}</td>
              <td>${l.opponent || '-'}</td>
              <td class="fw-bold text-primary">${l.ip_str || '-'}</td>
              <td>${l.np || 0}</td>
              <td>${l.h || 0}</td>
              <td>${l.r || 0}</td>
              <td class="fw-bold text-danger">${l.er || 0}</td>
              <td>${l.bb || 0}</td>
              <td class="fw-bold text-success">${l.so || 0}</td>
              <td>${l.hr || 0}</td>
              <td><span class="badge bg-light text-dark border">${l.decision || '-'}</span></td>
            </tr>`;
          });
          document.getElementById('trendLogsTbody').innerHTML = logsHtml || '<tr><td colspan="11" class="py-3 text-muted">기록이 없습니다.</td></tr>';
        } else {
          document.getElementById('trendLogsThead').innerHTML = `
            <tr><th>경기일</th><th>상대팀</th><th>타수</th><th>득점</th><th>안타</th><th>2루타</th><th>3루타</th><th>홈런</th><th>타점</th><th>볼넷</th><th>삼진</th><th>도루</th><th>경기타율</th></tr>
          `;
          let logsHtml = '';
          logs.forEach(l => {
            logsHtml += `<tr>
              <td>${l.match_date}</td>
              <td>${l.opponent || '-'}</td>
              <td>${l.ab || 0}</td>
              <td>${l.r || 0}</td>
              <td class="fw-bold text-primary">${l.h || 0}</td>
              <td>${l['2b'] || 0}</td>
              <td>${l['3b'] || 0}</td>
              <td class="fw-bold text-danger">${l.hr || 0}</td>
              <td class="fw-bold text-success">${l.rbi || 0}</td>
              <td>${l.bb || 0}</td>
              <td>${l.so || 0}</td>
              <td>${l.sb || 0}</td>
              <td class="fw-bold">${l.avg_in_game || '.000'}</td>
            </tr>`;
          });
          document.getElementById('trendLogsTbody').innerHTML = logsHtml || '<tr><td colspan="13" class="py-3 text-muted">기록이 없습니다.</td></tr>';
        }
      } catch (err) {
        console.error(err);
        alert('선수 세이버메트릭스 & 롤링 통계 조회 실패');
      }
    }

    function copyApiJson() {
      const txt = document.getElementById('apiJsonPreview').textContent;
      navigator.clipboard.writeText(txt).then(() => {
        alert('클라이언트 앱 연동용 JSON이 클립보드에 복사되었습니다.');
      });
    }
  </script>
</body>
</html>
'''

target_path = os.path.join(os.path.dirname(__file__), "app", "templates", "index.html")
with open(target_path, "w", encoding="utf-8") as f:
    f.write(html_content)

print(f"Successfully generated baseball UI at: {target_path} (size: {len(html_content)} bytes)")
